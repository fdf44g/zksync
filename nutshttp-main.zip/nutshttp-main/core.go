package nutshttp

import (
	"github.com/xujiajun/nutsdb"
)

type core struct {
	db *nutsdb.DB
}
